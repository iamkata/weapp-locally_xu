// pages/profile/profile.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null
  },
  // 获取用户信息的回调方法
  getUserInfo(e) {
    console.log(e.detail.userInfo)
    this.setData({
      // 用户信息
      userInfo: e.detail.userInfo
    })
  }
})