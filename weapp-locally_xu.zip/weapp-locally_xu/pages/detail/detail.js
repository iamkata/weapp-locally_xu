// 导入封装好的数据请求函数
const fetch = require('../../utils/fetch')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    shop: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options.item)
    fetch(`/shops/${options.item}`)
    .then(res => {
      console.log(res)
      this.setData({ shop: res.data })
      wx.setNavigationBarTitle({
        title: res.data.name,
      })
    })
  },
  // 点击了图片，开始预览
  previewHandle(e) {
    wx.previewImage({
      // 需要预览的图片链接列表
      urls: this.data.shop.images,
      // 当前显示图片的链接
      current: e.target.dataset.src
    })
  }
})