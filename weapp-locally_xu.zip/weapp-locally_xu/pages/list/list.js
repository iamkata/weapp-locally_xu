// 导入封装好的数据请求函数
const fetch = require('../../utils/fetch.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 当前的分类
    category: null,
    // 此分类下的所有店铺
    shops: [],
    pageIndex: 0,
    pageSize: 20,
    totalCount: 0,
    // 上拉加载的显示和隐藏
    hasMore: true,
    // 是否正在加载更多数据
    isLoadingMore: false,
    // 搜索框的文字
    searchText: '',
    // 搜索框的显示和隐藏
    searchShowed: false
  },
  // 加载下一页数据
  loadMore() {
    // 需要判断用户是否在正在加载，如果在就不加载，否则会有多次触发的问题
    // 如果正在加载更多数据，直接return
    if (this.data.isLoadingMore) return
    // 如果没更多数据，直接返回
    if (!this.data.hasMore) return
    // 设置正在加载更多
    this.setData({ isLoadingMore:true })
    // 解构赋值
    let { pageIndex, pageSize, searchText } = this.data
    const params = {
      // pageIndex先++后使用
      _page: ++pageIndex,
      _limit: pageSize
    }
    // 如果搜索框有文字，就传进去
    if (searchText) {
      params.q = searchText
    }
    return fetch(`categories/${this.data.category.id}/shops`, params).then(res => {
      // 在响应头获取总数据条数
      const totalCount = parseInt(res.header['x-total-count'])
      // console.log(totalCount)
      // 判断是否有更多数据
      const hasMore = pageIndex * pageSize < totalCount
      // concat：数组的拼接方法，结果是拼接后的新数组
      const shops = this.data.shops.concat(res.data)
      // 同步数据
      this.setData({ shops: shops, pageIndex, hasMore , totalCount, isLoadingMore: false })
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 请求当前分类的信息
    fetch(`categories/${options.cat}`).then(res => {
      // 设置导航栏标题一定要在onReady函数之后，由于数据请求是异步的，不能保证谁在前谁在后
      // wx.setNavigationBarTitle({
      //   title: res.data.name
      // })
      // 所以这里我们把请求到的数据放到data中，然后在onReady里面再设置一下标题，相当于双保险
      this.setData({ category: res.data })
      wx.setNavigationBarTitle({
        title: res.data.name
      })
      // 加载完分类信息再去加载商铺信息
      this.loadMore()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 如果name有值，说明数据请求完成了，然后再设置标题
    if (this.data.category.name) {
      wx.setNavigationBarTitle({
        title: this.data.category.name
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    // 清空数据
    this.setData({ shops: [], pageIndex: 0, hasMore: true, isLoadingMore: false })
    // 重新加载数据
    // 如果这一步没看懂，就是promise还没完全弄明白
    this.loadMore().then(() => wx.stopPullDownRefresh())
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    // 在这里加载下一页的数据
    this.loadMore()
  },

  /**
   * 搜索相关逻辑
   */

  // 开始搜索 点击键盘的enter或者手机的搜索按钮的时候触发
  searchHandle() {
    // 清空数据
    this.setData({ shops: [], pageIndex: 0, hasMore: true, isLoadingMore: false })
    // 加载新数据
    this.loadMore()
  },
  // 搜索框显示
  showSearchHandle() {
    this.setData({ searchShowed: true })
  },
  // 搜索框隐藏
  hideSearchHandle() {
    this.setData({ searchText: '', searchShowed: false })
    // 重新搜索
    this.searchHandle()
  },
  // 清空搜索框
  clearSearchHandle() {
    this.setData({ searchText: '' })
  },
  // 搜索框文字改变
  searchChangeHandle(e) {
    this.setData({ searchText: e.detail.value })
  }
})