// 导入封装好的数据请求函数
const fetch = require('../../utils/fetch.js')

Page({
  /**
   * 页面的初始数据
   */
  data: {
    // 轮播图数据
    slides: [],
    // slides: [
    //   {
    //     "id": 1,
    //     "image": "http://ww1.sinaimg.cn/mw690/006ThXL5ly1fj7zx3w751j30u00dmgy3.jpg",
    //     "link": ""
    //   },
    //   {
    //     "id": 2,
    //     "image": "http://ww1.sinaimg.cn/mw690/006ThXL5ly1fj6ckx9tlwj30u00fqk8n.jpg",
    //     "link": "/pages/list/list?cat=10"
    //   }
    // ]
    // 九宫格数据
    categories: [],
    // categories: [
    //   {
    //     "id": 1,
    //     "name": "美食",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i2onyj302u02umwz.jpg"
    //   },
    //   {
    //     "id": 2,
    //     "name": "洗浴足疗",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i2j4dj302u02umwy.jpg"
    //   },
    //   {
    //     "id": 3,
    //     "name": "结婚啦",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i56i0j302u02u744.jpg"
    //   },
    //   {
    //     "id": 4,
    //     "name": "卡拉OK",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i2uzvj302u02udfo.jpg"
    //   },
    //   {
    //     "id": 5,
    //     "name": "找工作",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i2rnlj302u02umwz.jpg"
    //   },
    //   {
    //     "id": 6,
    //     "name": "辅导班",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i2zloj302u02udfn.jpg"
    //   },
    //   {
    //     "id": 7,
    //     "name": "汽车保养",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i69eij302u02ua9w.jpg"
    //   },
    //   {
    //     "id": 8,
    //     "name": "租房",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i6j2lj302u02u0sj.jpg"
    //   },
    //   {
    //     "id": 9,
    //     "name": "装修",
    //     "icon": "http://ww1.sinaimg.cn/large/006ThXL5ly1fj8w5i6z1pj302u02ua9u.jpg"
    //   }
    // ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 豆瓣官方地址屏蔽了小程序的访问，我们使用Nginx，然后访问https://locally.uieee.com即可拿到数据，为了防止以后接口再失效，把实际数据也记录在data中了
    // 请求轮播图数据
    fetch('slides').then(res => {
      this.setData({ slides: res.data })
    })
    // 请求九宫格数据
    fetch('categories').then(res => {
      this.setData({ categories: res.data })
    })
    
    // wx.request({
    //   // 1. 发送请求不再是Web那一套Ajax
    //   // 2. 微信小程序没有跨域的概念，因为微信小程序不是前端，微信小程序就相当于客户端
    //   // 3. 请求的地址必须在管理后台添加白名单
    //   // 4. 域名必须备案，服务端必须采用HTTPS
    //   url: 'https://api.douban.com/v2/movie/coming_soon',
    //   header: {
    //     'content-type': 'json'
    //   },
    //   success: function(res) {
    //     console.log(res)
    //   }
    // })
  }
})