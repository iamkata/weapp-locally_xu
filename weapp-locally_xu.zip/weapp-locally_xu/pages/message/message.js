// pages/message/message.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    messages: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const messages = this.data.messages
    for (var i = 0; i < 18; i++) {
      messages.push({
        title: '免费送票！超有内涵的门票',
        date: i + 'September',
        image: 'https://unsplash.it/400/300',
        summary: '最糟糕的，也许就是最幸运的'
      })
    }
    this.setData({messages})
    // console.log(this.data.messages)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady () {
    // 返回一个 SelectorQuery 对象实例
    const query = wx.createSelectorQuery()
    // query.select('#bottom') 获取id为bottom的节点
    // boundingClientRect() 添加节点的布局位置的查询请求
    query.select('#bottom').boundingClientRect()
    // exec 执行所有的请求。请求结果按请求次序构成数组，在callback的第一个参数中返回。
    // scrollTop 滚动到页面的目标位置，单位 px
    query.exec(res => wx.pageScrollTo({ scrollTop: res[0].top + 200 }))
  }
})