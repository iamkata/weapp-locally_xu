// 配置baseurl
App({
  config: {
    apiBase: 'https://locally.uieee.com/'
  }
})